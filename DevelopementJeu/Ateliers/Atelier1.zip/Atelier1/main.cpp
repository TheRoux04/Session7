#include "Application.hpp"

using namespace std;

int main(int argc, char* argv[]){
    Application *app = new Application();
    app->start();

    return 0;
};
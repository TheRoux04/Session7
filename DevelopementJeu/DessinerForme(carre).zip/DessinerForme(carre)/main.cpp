#include "Application.hpp"
#include "SDLRenderer.hpp"

int main(int argc, char* argv[]){
    Application::getInstance().start();

    return 0;
};
#include <SDL2/SDL.h>
#include <SDL2/SDL_main.h>

int main(int argc, char* argv[]) {
  return 0;
}

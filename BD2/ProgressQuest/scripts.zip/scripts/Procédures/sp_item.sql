CREATE PROC sp_ajouterPerso
@nom nvarchar(30), @race int, @classe int, @hp int, @xp int, @niveau int, @force int, @defense int, @dext int, @or int
AS
INSERT INTO Personnage(PersoNom, PersoRaceCode, PersoClasseCode, PersoXp, PersoLevel, PersoHp, PersoMaxHp, PersoForce, PersoDefense, PersoDext, PersoOr)
VALUES (@nom, @race, @classe, @xp, @niveau, @hp, @hp, @force, @defense, @dext, @or)
GO

CREATE PROC sp_modifierPerso
@id int, @nom nvarchar(30), @race int, @classe int, @hp int, @xp int, @niveau int, @force int, @defense int, @dext int, @or int
AS
UPDATE Personnage 
SET PersoNom = @nom, PersoRaceCode = @race, PersoClasseCode = @classe, PersoXp = @xp, PersoLevel = @niveau, PersoHp = @hp, PersoMaxHp = @hp, PersoForce = @force, PersoDefense = @defense, PersoDext = @dext, PersoOr = @or
WHERE PersoCode = @id
GO

CREATE PROC sp_supprimerPerso
@id int
AS
DELETE FROM Personnage WHERE PersoCode = @id
GO

CREATE PROCEDURE sp_ajouterItem
@nom nvarchar(30), @valeur int
AS
INSERT INTO Item (ItemNom, ItemValeur) VALUES (@nom, @valeur)
GO

CREATE PROCEDURE sp_modifierItem
@id int, @nom nvarchar(30), @valeur int
AS
UPDATE Item SET ItemNom = @nom , ItemValeur = @valeur WHERE ItemCode = @id
GO

CREATE PROCEDURE sp_supprimerItem
@id int
AS
DELETE FROM Item WHERE ItemCode = @id
GO

CREATE PROC sp_ajouterRace
@nom nvarchar(30)
AS
INSERT INTO Race (RaceNom) VALUES (@nom)
GO

CREATE PROC sp_modifierRace
@id int, @nom nvarchar(30)
AS
UPDATE Race SET RaceNom = @nom WHERE RaceCode = @id
GO

CREATE PROC sp_supprimerRace
@id int
AS
DELETE FROM Race WHERE RaceCode = @id
GO

CREATE PROCEDURE sp_ajouterClasse
@nom nvarchar(30), @force int, @defense int, @dext int, @hp int, @or int
AS
INSERT INTO Classe (ClasseNom, ClasseForce, ClasseDef, ClasseDext, ClasseHp, ClasseOr) VALUES (@nom, @force, @defense, @dext, @hp, @or)
GO

CREATE PROCEDURE sp_modifierClasse
@id int, @nom nvarchar(30), @force int, @defense int, @dext int, @hp int, @or int
AS
UPDATE Classe SET ClasseNom = @nom, ClasseForce = @force, ClasseDef = @defense, ClasseDext = @dext, ClasseHp = @hp, ClasseOr = @or 
WHERE ClasseCode = @id
GO

CREATE PROCEDURE sp_supprimerClasse
@id int
AS
DELETE FROM Classe WHERE ClasseCode = @id
GO

CREATE PROCEDURE sp_ajouterEnnemi
@nom nvarchar(30), @niveau int, @hp int, @maxHp int, @force int, @defense int, @boss bit, @or int
AS 
INSERT INTO Ennemi (EnnemiNom, EnnemiLevel, EnnemiMaxHp, EnnemiHp, EnnemiForce, EnnemiDefense, estBoss, EnnemiOr) VALUES (@nom, @niveau, @maxHp, @hp, @force, @defense, @boss, @or)
GO

CREATE PROCEDURE sp_modifierEnnemi
@id int, @nom nvarchar(30), @niveau int, @hp int, @maxHp int, @force int, @defense int,  @boss bit, @or int
AS 
UPDATE Ennemi SET EnnemiNom = @nom, EnnemiLevel = @niveau, EnnemiMaxHp = @maxHp, EnnemiHp = @hp, EnnemiForce = @force, EnnemiDefense = @defense, estBoss = @boss, EnnemiOr = @or WHERE EnnemiCode = @id
GO

CREATE PROCEDURE sp_supprimerEnnemi
@id int
AS 
DELETE FROM Ennemi WHERE EnnemiCode = @id
GO

CREATE PROC sp_ajouterDropEnnemi
@ennemiId int, @itemId int, @itemQte int
AS
INSERT INTO ButinEnnemi (ButinEnnEnnemiCode, ButinEnnItemCode, ButinEnnItemQte) VALUES (@ennemiId, @itemId, @itemQte)
GO

CREATE PROC sp_modifierDrop
@dropId int, @qte int
AS
UPDATE ButinEnnemi SET ButinEnnItemQte = @qte WHERE ButinEnnCode = @dropId
GO

CREATE PROC sp_supprimerDropEnnemi
@dropId int
AS
DELETE FROM ButinEnnemi WHERE ButinEnnCode = @dropId
GO

CREATE PROCEDURE sp_modifierNbEnnemiDonj
@donjEnnId int, @quantite int
AS 
UPDATE DonjEnnemi SET DonjEnnNbEnnemi = @quantite WHERE DonjEnnCode = @donjEnnId
GO

CREATE PROCEDURE sp_ajouterDonjon
@nom nvarchar(30), @niveau int
AS
INSERT INTO Donjon(DonjNom, DonjLevel) VALUES (@nom, @niveau)
GO

CREATE PROCEDURE sp_modifierDonjon
@donjonId int, @nom nvarchar(30), @niveau int
AS
UPDATE Donjon SET DonjNom = @nom , DonjLevel = @niveau WHERE DonjCode = @donjonId
GO

CREATE PROCEDURE sp_supprimerDonjon
@donjonId int
AS
DELETE FROM Donjon WHERE DonjCode = @donjonId
GO


//Nouveau

CREATE PROCEDURE sp_ajouterEnnemiDonjon
@donjonId int, @ennemiId nvarchar(30), @ennemiQte int
AS
INSERT INTO DonjEnnemi(DonjEnnEnnemiCode, DonjEnnDonjonCode, DonjEnnNbEnnemi) VALUES (@ennemiId, @donjonId, @ennemiQte) 


CREATE PROCEDURE sp_supprimerEnnemiDonjon
@donjEnnemiId int
AS 
DELETE FROM DonjEnnemi WHERE DonjEnnCode = @donjEnnemiId


CREATE PROCEDURE sp_modifierNbEnnemiDonj
@donjEnnId int, @quantite int
AS 
UPDATE DonjEnnemi SET DonjEnnNbEnnemi = @quantite WHERE DonjEnnCode = @donjEnnId

CREATE PROCEDURE sp_ajouterQuete
@nom nvarchar(30), @niveau int, @description nvarchar(100), @xp int, @or int, @equipementId int, @itemId int, @itemQte int, @donjonId int
AS
INSERT INTO Quete (QueteNom, QueteLevel, QueteDescription, QueteXpQte, QueteOrQte, QueteEquipementCode, QueteItemCode, QueteItemQte, QueteDonjonCode) 
VALUES (@nom, @niveau, @description, @xp, @or, @equipementId, @itemId, @itemQte, @donjonId)


CREATE PROCEDURE sp_modifierQuete
@queteId int, @nom nvarchar(30), @niveau int, @description nvarchar(100), @xp int, @or int, @equipementId int, @itemId int, @itemQte int, @donjonId int
AS 
UPDATE Quete SET QueteNom = @nom, QueteLevel = @niveau, QueteDescription = @description, QueteXpQte = @xp, QueteOrQte = @or, QueteEquipementCode = @equipementId, QueteItemCode = @itemId, QueteItemQte = @itemQte, QueteDonjonCode = @donjonId
WHERE QueteCode = @queteId

DROP FUNCTION IF EXISTS dbo.fntItemClick;
GO

CREATE FUNCTION fntItemClick(@id int)
RETURNS TABLE
AS
RETURN SELECT ItemNom, ItemValeur FROM Item WHERE ItemCode = @id
GO


DROP FUNCTION IF EXISTS dbo.fntQueteClick;
GO

CREATE FUNCTION fntQueteClick(@id int)
RETURNS TABLE
AS
RETURN SELECT QueteCode AS Code, QueteNom AS NomQ, QueteDescription AS DescriptionQ, QueteLevel AS LevelQ, QueteItemCode AS Item, QueteItemQte AS ItemQte, QueteOrQte AS OrQ, QueteXpQte AS XP, QueteDonjonCode AS Donjon, QueteEquipementCode AS EquipementRecompense FROM Quete 
INNER JOIN Item ON Quete.QueteItemCode = Item.ItemCode 
INNER JOIN Equipement ON Equipement.EquipCode = Quete.QueteEquipementCode
GO

CREATE FUNCTION fntAfficherPerso(@id int)
RETURNS TABLE
AS
RETURN SELECT * FROM Personnage WHERE PersoCode = @id
GO

CREATE FUNCTION fntAfficherClasse(@id int)
RETURNS TABLE
AS
RETURN SELECT * FROM Classe WHERE ClasseCode = @id
GO

CREATE FUNCTION fntAfficherRace(@id int)
RETURNS TABLE
AS
RETURN SELECT RaceNom FROM Race WHERE RaceCode = @id
GO

CREATE FUNCTION fntEnnemiClick (@id int)
RETURNS TABLE
AS
RETURN SELECT * FROM Ennemi WHERE EnnemiCode = @id
GO

CREATE FUNCTION fntButinEnnemi(@EnnemiCode int)
RETURNS TABLE
AS
RETURN SELECT ButinEnnCode, ItemCode, ItemNom, ButinEnnItemQte FROM ButinEnnemi INNER JOIN Item ON ButinEnnItemCode = ItemCode WHERE ButinEnnEnnemiCode = @EnnemiCode
GO

CREATE FUNCTION fntButinItem(@ennemiId int)
RETURNS TABLE
AS
RETURN SELECT ItemCode, ItemNom FROM Item WHERE ItemCode NOT IN (SELECT ButinEnnItemCode FROM ButinEnnemi WHERE ButinEnnEnnemiCode = @ennemiId)
GO


CREATE FUNCTION fntNotEnnemiDonjon(@donjonId int)
RETURNS TABLE
AS
RETURN SELECT EnnemiCode, EnnemiNom FROM Ennemi WHERE EnnemiCode NOT IN (SELECT DonjEnnEnnemiCode FROM DonjEnnemi WHERE DonjEnnEnnemiCode = @donjonId)
GO

CREATE FUNCTION fntEnnemiDonjon(@donjonId int)
RETURNS TABLE
AS
RETURN SELECT DonjEnnEnnemiCode, EnnemiNom, DonjEnnNbEnnemi FROM DonjEnnemi INNER JOIN Ennemi ON Ennemi.EnnemiCode = DonjEnnemi.DonjEnnEnnemiCode WHERE DonjEnnemi.DonjEnnEnnemiCode = @donjonId
GO


CREATE FUNCTION fntButinQuete(@QueteCode int)
RETURNS TABLE
AS
RETURN SELECT ButinQueCode, ItemCode, ItemNom, ButinQueItemQte FROM ButinQuete INNER JOIN Item ON ButinQueItemCode = ItemCode WHERE ButinQueQueteCode = @QueteCode
GO

CREATE FUNCTION fntButinItemQuete(@queteId int)
RETURNS TABLE
AS
RETURN SELECT ItemCode, ItemNom FROM Item WHERE ItemCode NOT IN (SELECT ButinQueItemCode FROM ButinQuete WHERE ButinQueQueteCode = @queteId)
GO



//Nouveau

CREATE FUNCTION fntDonjonClick(@id int)
RETURNS TABLE
AS
RETURN SELECT DonjNom, DonjLevel FROM Donjon WHERE DonjCode = @id
GO

CREATE FUNCTION fntEnnemiDonjon(@donjonId int)
RETURNS TABLE
AS
RETURN SELECT DonjEnnCode, EnnemiNom, DonjEnnNbEnnemi FROM DonjEnnemi INNER JOIN Ennemi ON Ennemi.EnnemiCode = DonjEnnemi.DonjEnnEnnemiCode WHERE DonjEnnemi.DonjEnnDonjonCode = @donjonId

CREATE FUNCTION fntNotEnnemiDonjon(@donjonId int)
RETURNS TABLE
AS
RETURN SELECT EnnemiCode, EnnemiNom FROM Ennemi WHERE EnnemiCode NOT IN (SELECT DonjEnnEnnemiCode FROM DonjEnnemi WHERE DonjEnnDonjonCode = @donjonId)

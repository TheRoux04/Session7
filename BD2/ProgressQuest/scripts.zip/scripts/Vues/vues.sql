DROP VIEW IF EXISTS dbo.vuePersonnage;
GO

CREATE VIEW vuePersonnage
AS 
SELECT * FROM Personnage
GO

DROP VIEW IF EXISTS dbo.vueRace;
GO

CREATE VIEW vueRace
AS
SELECT * FROM Race
GO

DROP VIEW IF EXISTS dbo.vueEnnemi;
GO

CREATE VIEW vueEnnemi
AS
SELECT * FROM Ennemi
GO

DROP VIEW IF EXISTS dbo.vueItem;
GO

CREATE VIEW vueItem
AS 
SELECT * FROM Item
GO

DROP VIEW IF EXISTS dbo.vueClasse;
GO
CREATE VIEW vueClasse
AS
SELECT * FROM Classe
GO

DROP VIEW IF EXISTS dbo.vueQuete;
GO

CREATE VIEW vueQuete
AS
SELECT * FROM Quete
GO

DROP VIEW IF EXISTS dbo.vueEquipement;
GO

CREATE VIEW vueEquipement
AS
SELECT * FROM Equipement INNER JOIN Emplacement ON Equipement.EquipEmplacementCode = Emplacement.EmplacementCode
GO

DROP VIEW IF EXISTS dbo.vueDonjon;
GO

CREATE VIEW vueDonjon
AS
SELECT * FROM Donjon
GO

DROP VIEW IF EXISTS dbo.vueEmplacementEquip;
GO
CREATE VIEW vueEmplacementEquip AS
SELECT * FROM Emplacement
go




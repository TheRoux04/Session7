package main

import (
	"encoding/json"
	"io"
	"log"
	"models/message"
	"net/http"
	"os"
	userRepo "repositories/userRepo"
	"strconv"
	"strings"

	"github.com/gorilla/websocket"
	_ "github.com/mattn/go-sqlite3"
)

var upgrader = websocket.Upgrader{}

func main() {
	var oniClients map[string]chan message.Message = make(map[string]chan message.Message)
	var oniTech chan message.Message = make(chan message.Message)
	defer close(oniTech)
	http.HandleFunc("/", gererConnection)

	http.HandleFunc("/logout", logout)
	http.HandleFunc("/logoutAdmin", logoutAdmin)
	http.HandleFunc("/404", error404)

	http.HandleFunc("/client", func(w http.ResponseWriter, r *http.Request) {
		client(w, r, oniClients)
	})
	http.HandleFunc("/tech", tech)

	http.HandleFunc("/admin", admin)
	http.HandleFunc("/logs", logs)
	http.HandleFunc("/add", addUser)
	http.HandleFunc("/edit", editUser)
	http.HandleFunc("/delete", deleteUser)

	http.HandleFunc("/ws", ws)
	http.HandleFunc("/wsMessageTech", func(w http.ResponseWriter, r *http.Request) {
		wsMessageTech(w, r, oniClients, oniTech)
	})
	http.HandleFunc("/wsMessageClient", func(w http.ResponseWriter, r *http.Request) {
		wsMessageClient(w, r, oniTech, oniClients)
	})

	fileServer := http.FileServer(http.Dir("./assets"))
	http.Handle("/assets/", http.StripPrefix("/assets/", fileServer))

	http.ListenAndServe(":8080", nil)
}

func gererConnection(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.Error(w, "404 Not Found", http.StatusNotFound)
		http.Redirect(w, r, "/404", http.StatusTemporaryRedirect)
		return

	} else {
		switch r.Method {
		case "GET":

			content, _ := os.ReadFile("./views/home.html")
			w.Header().Set("Content-Type", "text/html")
			io.WriteString(w, string(content))
			log.Println("loading view")

		case "POST":

			r.ParseForm()
			username := r.Form.Get("username")
			password := r.Form.Get("password")

			if username != "" && password != "" {
				isUser, token := userRepo.VerifyUser(username, password)

				switch isUser {
				case 0:
					log.Println("Utilisateur non trouvé")
					http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
					return
				case 1:
					log.Println("Utilisateur trouvé")
					var responseCookie http.Cookie = http.Cookie{Name: "connected", Value: token}
					http.SetCookie(w, &responseCookie)
					userRepo.SetConnected(token, username)
					userRepo.LogConnexion(username)
					http.Redirect(w, r, "/tech", http.StatusTemporaryRedirect)
					return
				case 2:
					log.Println("Administrateur trouvé")
					var responseCookie http.Cookie = http.Cookie{Name: "connected", Value: token}
					http.SetCookie(w, &responseCookie)

					http.Redirect(w, r, "/admin", http.StatusTemporaryRedirect)
					return
				}
			}
		}
	}

}

func error404(w http.ResponseWriter, r *http.Request) {
	content, err := os.ReadFile("./views/404.html")
	if err != nil {
		log.Println(err)
	}
	w.Header().Set("Content-Type", "text/html")
	io.WriteString(w, string(content))
}

func admin(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("connected")
	if err != nil {
		log.Println(err)
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}
	if cookie.Value == userRepo.GetToken(cookie.Value) {

		content, _ := os.ReadFile("./views/admin.html")
		vue := string(content)
		users := userRepo.GetAllUsers()
		var elements string
		var tabUser []string

		if users != nil {
			elements += "<ul class='list-group d-flex' id='techs'>"
			for key, user := range users {
				if key < len(users)-1 {
					tabUser = strings.Split(user, ";")
					elements += "<li class='list-group-item d-flex'>"
					elements += "<p class='flex-grow-1'>" + tabUser[1] + "</p>"
					elements += `<a class="btn btn-info rounded-start rounded-0 me-1" href="/edit?id=` + tabUser[0] + `">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
						<path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
						</svg>
						</a>
						<a type="submit" class="btn btn-danger rounded-end rounded-0" href="/delete?id=` + tabUser[0] + `">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
							<path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
							</svg>
						</a>
						`
					elements += "</li>"
				}
			}
			elements += "</ul>"
		}
		vue = strings.Replace(vue, `<p class="invisible"></p>`, elements, 1)
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, vue)
	}

}

func logs(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("connected")
	if err != nil {
		log.Println(err)
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}
	if cookie.Value == userRepo.GetToken(cookie.Value) {

		content, _ := os.ReadFile("./views/logs.html")
		vue := string(content)
		logs := userRepo.GetAllLogs()
		var tabLogs []string
		elements := ""
		if logs != nil {
			for key, eachLog := range logs {
				if key < len(logs)-1 {
					tabLogs = strings.Split(eachLog, ";")
					elements += "<p>" + tabLogs[0] + " - " + tabLogs[1] + " en date du " + tabLogs[2] + " au " + tabLogs[3] + "</p>"
				}
			}
		}
		vue = strings.Replace(vue, `<p class="invisible"></p>`, elements, 1)
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, vue)
	}
}

func logout(w http.ResponseWriter, r *http.Request) {
	cookie, _ := r.Cookie("connected")
	if cookie != nil {
		userRepo.LogDeconnexion(cookie.Value)
		userRepo.LogoutUser(cookie.Value)
		var responseCookie http.Cookie = http.Cookie{Name: "connected", Value: "false", MaxAge: -1}
		http.SetCookie(w, &responseCookie)
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
	} else {
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
	}
}

func logoutAdmin(w http.ResponseWriter, r *http.Request) {

	cookie, _ := r.Cookie("connected")
	if cookie != nil {

		var responseCookie http.Cookie = http.Cookie{Name: "connected", Value: "false", MaxAge: -1}
		http.SetCookie(w, &responseCookie)
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
	} else {
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
	}
}

func addUser(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":

		content, _ := os.ReadFile("./views/add.html")
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, string(content))

	case "POST":

		r.ParseForm()
		username := r.Form.Get("username")
		password := r.Form.Get("password")

		if username != "" && password != "" {
			r.ParseForm()
			username := r.Form.Get("username")
			password := r.Form.Get("password")

			if username != "" && password != "" {
				userRepo.InsertUser(username, password)
			}
			log.Println("Utilisateur ajouté")
			http.Redirect(w, r, "/admin", http.StatusTemporaryRedirect)
		} else {
			http.Redirect(w, r, "/add", http.StatusTemporaryRedirect)
		}
	}

}

func editUser(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":

		content, _ := os.ReadFile("./views/edit.html")
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, string(content))

	case "POST":
		output := r.URL.Query().Get("id")
		id, _ := strconv.Atoi(output)
		r.ParseForm()
		username := r.Form.Get("username")
		password := r.Form.Get("password")

		if username != "" && password != "" {
			r.ParseForm()
			username := r.Form.Get("username")
			password := r.Form.Get("password")

			if username != "" && password != "" {
				log.Println("Utilisateur modifié")
				userRepo.EditUser(username, password, id)
			}
			http.Redirect(w, r, "/admin", http.StatusTemporaryRedirect)
		} else {
			http.Redirect(w, r, "/edit?"+output, http.StatusTemporaryRedirect)
		}
	}
}

func deleteUser(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
		content, _ := os.ReadFile("./views/delete.html")
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, string(content))

	case "POST":
		output := r.URL.Query().Get("id")
		id, _ := strconv.Atoi(output)
		userRepo.DeleteUser(id)
		http.Redirect(w, r, "/admin", http.StatusTemporaryRedirect)
	}

}

func tech(w http.ResponseWriter, r *http.Request) {
	_, err := r.Cookie("connected")
	if err != nil {
		log.Println("Erreur cookie")
		log.Println(err)
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}
	content, _ := os.ReadFile("./views/tech.html")
	w.Header().Set("Content-Type", "text/html")
	io.WriteString(w, string(content))
}

func client(w http.ResponseWriter, r *http.Request, oniClients map[string]chan message.Message) {
	if userRepo.IsTechConnected() {
		id := len(oniClients) + 1
		oniClients[strconv.Itoa(id)] = make(chan message.Message)

		content, _ := os.ReadFile("./views/client.html")
		vue := string(content)
		vue = strings.Replace(vue, "###ID###", strconv.Itoa(id), 1)
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, vue)
	} else {
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
	}

}

func ws(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println(err)
		return
	}
	if userRepo.IsTechConnected() {
		err = conn.WriteMessage(websocket.TextMessage, []byte("online"))
		if err != nil {
			log.Println(err)
			return
		}
	} else {
		err = conn.WriteMessage(websocket.TextMessage, []byte("offline"))
	}
}

func wsMessageTech(w http.ResponseWriter, r *http.Request, oniClients map[string]chan message.Message, oniTech <-chan message.Message) {
	conn, err := upgrader.Upgrade(w, r, nil)
	w.Header().Add("Content-Type", "text/json")
	defer conn.Close()
	var oniClosed chan bool = make(chan bool)
	defer close(oniClosed)
	log.Println("Connection au WebSocket; ", r.RemoteAddr)
	if err != nil {
		log.Print("upgrade:", err)
		return
	}
	go writeClient(conn, oniClients, oniClosed)
	for {
		select {
		case msg := <-oniTech:
			log.Println("Message reçu du client: ", msg)
			conn.WriteJSON(msg)

		case <-oniClosed:
			log.Println("Tech déconnecté")
			return
		}

	}

}
func wsMessageClient(w http.ResponseWriter, r *http.Request, oniTech chan<- message.Message, oniClients map[string]chan message.Message) {
	conn, err := upgrader.Upgrade(w, r, nil)
	w.Header().Add("Content-Type", "text/json")
	defer conn.Close()
	var oniClosed chan bool = make(chan bool)
	defer close(oniClosed)
	log.Println("Connection au WebSocket; ", r.RemoteAddr)
	if err != nil {
		log.Print("upgrade:", err)
		return
	}
	go writeTech(conn, oniTech, oniClosed)
	oniClient := oniClients[strconv.Itoa(len(oniClients))]
	log.Println("aaaaaa : ", oniClients["1"])
	for {
		select {
		case msg := <-oniClient:
			log.Println("Message reçu du technicien: ", msg)
			conn.WriteJSON(msg)
		case <-oniClosed:
			log.Println("Connexion fermée")
			return
		}

	}
}

func writeClient(conn *websocket.Conn, oniClients map[string]chan message.Message, oniClosed chan<- bool) {
	var message message.Message

	defer func() { oniClosed <- true }()
	for {
		typeMsg, msg, err := conn.ReadMessage()

		if err != nil {
			log.Println(err)
			break
		}
		if typeMsg == -1 || typeMsg == websocket.CloseMessage {
			log.Println("Connexion fermée")
			break
		}
		err = json.Unmarshal(msg, &message)
		id := strconv.Itoa(message.Destination)
		log.Println("ID: ", id)

		conn.WriteJSON(message)

		log.Println("Envoi au client", message)
		oniClients[id] <- message

	}
}

func writeTech(conn *websocket.Conn, oniTech chan<- message.Message, oniClosed chan<- bool) {
	var message message.Message
	defer func() { oniClosed <- true }()
	for {
		typeMsg, msg, err := conn.ReadMessage()

		if err != nil {
			log.Println(err)
			break
		}
		log.Println("Message reçu du client: ", string(msg))
		if typeMsg == -1 || typeMsg == websocket.CloseMessage {
			log.Println("Connexion fermée")
			break
		}

		err = json.Unmarshal(msg, &message)
		if err != nil {
			log.Println(err)
			break
		}
		conn.WriteJSON(message)
		log.Println("Envoi", message)
		oniTech <- message

	}
}

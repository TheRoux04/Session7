let ws = new WebSocket("ws://localhost:8080/wsMessageTech");
let id = 0;
let idClient = 1;
let mapClients = new Map();
ws.onmessage = function (event) {
    let message = JSON.parse(event.data);
    console.log(message);
    let content 
    let div = document.getElementById("message-container");
    let p = document.createElement("p");

    if (message.content === "Client connected") {
        mapClients.set(message.id, "");
        document.getElementById("client-container").innerHTML = "";
        idClient = message.id;
        mapClients.forEach((value, key) => {
            document.getElementById("client-container").innerHTML += `
            <button class='btn btn-primary' id='client-` + key + `' onclick='selectClient(` + key + `)'>` + key + `</button>`;
        }, mapClients);
    }

    else if (message.content === "Client disconnected") {
        mapClients.delete(message.id);
        document.getElementById("client-container").innerHTML = "";
        mapClients.forEach((value, key) => {
            document.getElementById("client-container").innerHTML += `
            <button class='btn btn-primary' id='client-` + key + `' onclick='selectClient(` + key + `)'>` + key + `</button>`;
        }, mapClients);
    }

    else {
        let div = document.getElementById("message-container");
        div.innerText = "";
        let p;
        let convo = "";
        if (message.id === id) {
            convo = mapClients.get(idClient);
            convo += "Tech: " + message.content + "\n";
            mapClients.set(idClient, convo);
        } 
        else {
            convo = mapClients.get(message.id);
            convo += "Client: " + message.content + "\n";
            mapClients.set(message.id, convo);
        }

        let tabConvo = mapClients.get(idClient).split("\n");
        tabConvo.forEach(element => {
            p = document.createElement("p");
            p.innerHTML = element;
            div.appendChild(p);
        });
    }
}
document.getElementById("envoyer").addEventListener("click", function () {
    let message = document.getElementById("message").value;
    ws.send(JSON.stringify({
        id: id,
        content: message,
        destination: idClient
    }));

});

function selectClient(id) {
    idClient = id;
    let div = document.getElementById("message-container");
    div.innerText = "";
    convo = mapClients.get(id).split("\n");
    convo.forEach(element => {
        let p = document.createElement("p");
        p.innerHTML = element;
        div.appendChild(p);
    });
}

window.addEventListener("beforeunload", function (event) {
    ws.close();
});
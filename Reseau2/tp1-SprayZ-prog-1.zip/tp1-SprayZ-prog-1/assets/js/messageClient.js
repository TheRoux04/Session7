let ws = new WebSocket("ws://localhost:8080/wsMessageClient");
let id = 0;

ws.onopen = function (event) {
    id = parseInt(document.getElementById("id").value, 10);
    console.log(id);
    ws.send(JSON.stringify({
        id: id,
        content: "Client connected",
        destination: 0
    }));
};
ws.onclose = function (event) {
    ws.send(JSON.stringify({
        id: id,
        content: "Client disconnected",
        destination: 0
    }));
};
ws.onmessage = function (event) {
    let message = JSON.parse(event.data);

    if (message.content != "Client connected" && message.content != "Client disconnected") {
    
        let message = JSON.parse(event.data);
        console.log(message);
        let div = document.getElementById("message-container");
        let p = document.createElement("p");
        if (message.id === id) {
            p.innerHTML = "Client: " + message.content;
        } else if (message.content != "Client connected" && message.content != "Client disconnected") {
            p.innerHTML = "Tech: " + message.content;
        }
        div.appendChild(p);
    }
}
document.getElementById("envoyer").addEventListener("click", function () {
    let message = document.getElementById("message").value;
    ws.send(JSON.stringify({
        id: id,
        content: message,
        destination: 0
    }));

});

window.addEventListener("beforeunload", function (event) {
    ws.close();
});
let ws = new WebSocket("ws://localhost:8080/ws");

ws.onopen = function () {
    console.log("Connection established!");
};
ws.onmessage = function (event) {
    var message = event.data;

    if (message == "online") {
        var btn = document.getElementById("online");
        btn.classList.remove("d-none");
        var btn = document.getElementById("offline");
        btn.classList.add("d-none");
    }
    else {
        var btn = document.getElementById("online");
        btn.classList.add("d-none");
        var btn = document.getElementById("offline");
        btn.classList.remove("d-none");
    }
}
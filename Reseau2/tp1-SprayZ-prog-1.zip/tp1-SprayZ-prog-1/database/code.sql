CREATE TABLE Technicien (
	tech_id INTEGER PRIMARY KEY AUTOINCREMENT,
	tech_username varchar(30) NOT NULL,
	tech_password varchar(30) NOT NULL,
	tech_token varchar(30) NOT NULL,
	tech_connected BOOLEAN DEFAULT 0,
	tech_admin BOOLEAN DEFAULT 0
)

CREATE TABLE Logs(
	logs_id INTEGER PRIMARY KEY AUTOINCREMENT,
	logs_nom varchar(30) NOT NULL,
	logs_connexion DATE NULL,
	logs_deconnexion DATE NULL
)

INSERT INTO Technicien (tech_username, tech_password, tech_token, tech_admin) VALUES ('admin', '$2a$14$8gZFH92bdT/z5b21XAZMTOIFV02CLbgYw.ZT.M6H0W241S6GUHasq', '', 1);
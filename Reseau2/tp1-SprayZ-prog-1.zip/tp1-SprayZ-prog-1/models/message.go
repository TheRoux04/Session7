package message

type Message struct {
	Id          int    `json:"id"`
	Content     string `json:"content"`
	Destination int    `json:"destination"`
}

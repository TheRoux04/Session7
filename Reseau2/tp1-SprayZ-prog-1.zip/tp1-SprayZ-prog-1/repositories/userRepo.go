package userRepo

import (
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"log"
	"strconv"
	"strings"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"golang.org/x/crypto/bcrypt"
)

func InsertUser(username string, password string) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)

	if err != nil {
		log.Fatal(err)
	}

	stmt, err := db.Prepare("INSERT INTO Technicien(tech_username, tech_password, tech_token, tech_connected) VALUES(?, ?, ?, ?)")
	if err != nil {
		log.Fatal(err)
	}

	_, err = stmt.Exec(username, hashedPassword, "", 0)
	if err != nil {
		log.Fatal(err)
	}
}

func VerifyUser(username string, password string) (int, string) {

	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	log.Println(password)
	if err != nil {
		log.Fatal(err)
	}

	var hashPassword string
	var isAdmin bool
	err = db.QueryRow("SELECT tech_password, tech_admin FROM Technicien WHERE tech_username = ?", username).Scan(&hashPassword, &isAdmin)
	if err != nil {
		log.Println(err)
		return 0, ""
	}

	if CheckPasswordHash(password, hashPassword) {
		token := InsertToken(username)
		if isAdmin {
			return 2, token
		}

		return 1, token
	}
	return 0, ""

}

func EditUser(username string, password string, id int) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)

	if err != nil {
		log.Fatal(err)
	}
	statement, err2 := db.Prepare("UPDATE Technicien SET tech_username = ?, tech_password = ? WHERE tech_id = ?")
	if err2 != nil {
		log.Fatal(err2)
	}

	statement.Exec(username, hashedPassword, id)
	if err != nil {
		log.Println(err)
		return
	}

}

func DeleteUser(id int) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}

	defer db.Close()

	statement, err2 := db.Prepare("DELETE FROM Technicien WHERE tech_id = ?")
	if err2 != nil {
		log.Fatal(err2)
	}

	statement.Exec(id)
	if err != nil {
		log.Println(err)
		return
	}

}
func GetAllUsers() []string {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	var tabUsers []string
	var users string
	row, err := db.Query("SELECT tech_id, tech_username FROM Technicien WHERE tech_admin = 0")
	if err != nil {
		log.Fatal(err)
		return nil
	}
	for row.Next() { // Iterate and fetch the records from result cursor
		var id int
		var code string

		row.Scan(&id, &code)

		users += strconv.Itoa(id) + ";" + code + "|"
	}
	if users != "" {
		tabUsers = strings.Split(users, "|")
		return tabUsers
	}
	return nil
}

func GetAllLogs() []string {

	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	var tabLogs []string
	var logs string
	row, err := db.Query("SELECT logs_id, logs_username, logs_connexion, logs_deconnexion FROM Logs WHERE logs_deconnexion IS NOT NULL")
	if err != nil {
		log.Fatal(err)
		return nil
	}

	for row.Next() { // Iterate and fetch the records from result cursor
		var id int
		var username string
		var connexion string
		var deconnexion string

		row.Scan(&id, &username, &connexion, &deconnexion)

		logs += strconv.Itoa(id) + ";" + username + ";" + connexion + ";" + deconnexion + "|"
	}
	if logs != "" {

		tabLogs = strings.Split(logs, "|")
		log.Println(tabLogs)
		return tabLogs
	}
	log.Println(logs)
	return nil
}

func LogoutUser(token string) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	statement, err2 := db.Prepare("UPDATE Technicien SET tech_token = ?, tech_connected = ? WHERE tech_token = ?")
	if err2 != nil {
		log.Fatal(err2)
	}
	statement.Exec("", 0, token)
	if err != nil {
		log.Println(err)
		return
	}
}

func InsertToken(username string) string {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	statement, err2 := db.Prepare("UPDATE Technicien SET tech_token = ?, tech_connected = ? WHERE tech_username = ?")
	if err2 != nil {
		log.Fatal(err2)
	}
	var token string = GenerateSecureToken(24)
	statement.Exec(token, 1, username)
	if err != nil {
		log.Println(err)
		return ""
	}
	return token
}

func GetToken(token string) string {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	var username string
	err = db.QueryRow("SELECT tech_token FROM Technicien WHERE tech_token = ?", token).Scan(&username)
	if err != nil {
		log.Println(err)
		return ""
	}
	return username
}

func SetConnected(token string, username string) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	statement, err2 := db.Prepare("UPDATE Technicien SET tech_connected = ?, tech_token = ? WHERE tech_username = ?")
	if err2 != nil {
		log.Fatal(err2)
	}
	statement.Exec(1, token)
	if err != nil {
		log.Println(err)
		return
	}
}

func IsTechConnected() bool {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	var connected bool
	err = db.QueryRow("SELECT tech_connected FROM Technicien WHERE tech_connected = 1 AND tech_admin = 0").Scan(&connected)
	if err != nil {
		log.Println(err)
		return false
	}
	return connected
}

func LogConnexion(username string) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	var id int
	err = db.QueryRow("SELECT tech_id FROM Technicien WHERE tech_username = ?", username).Scan(&id)
	if err != nil {
		log.Fatal(err)
	}

	statement, err2 := db.Prepare("INSERT INTO Logs (logs_idUser, logs_username, logs_connexion, logs_deconnexion) VALUES (?, ?, ?, NULL)")
	if err2 != nil {
		log.Fatal(err2)
	}
	statement.Exec(id, username, time.Now().Format("2006-01-02 15:04:05"))
}

func LogDeconnexion(token string) {
	db, err := sql.Open("sqlite3", "./database/technicien.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	var id int
	err = db.QueryRow("SELECT logs_id FROM Logs ORDER BY logs_id DESC LIMIT 1").Scan(&id)
	if err != nil {
		log.Fatal(err)
	}

	statement, err2 := db.Prepare("UPDATE Logs SET logs_deconnexion = ? WHERE logs_id = ?")
	if err2 != nil {
		log.Fatal(err2)
	}
	statement.Exec(time.Now().Format("2006-01-02 15:04:05"), id)
}

func GenerateSecureToken(length int) string {
	b := make([]byte, length)
	if _, err := rand.Read(b); err != nil {
		return ""
	}
	return hex.EncodeToString(b)
}

func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), 14)
	return string(bytes), err
}

func CheckPasswordHash(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}
